﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementClassLib.Entities
{
    public enum Role
    {
        admin,
        user
    }
    public class User : BaseEntity
    {

        [Required(ErrorMessage = "First Name is required")]
        [MaxLength(50, ErrorMessage = "First Name cannot exceed 50 characters")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is required")]
        [MaxLength(50, ErrorMessage = "Last Name cannot exceed 50 characters")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        public Role Role { get; set; }
        public string PasswordHash { get; set; }
        public DateTime CreatedAt { get; set; }

        [Phone(ErrorMessage = "Invalid Phone Number")]
        [MaxLength(15, ErrorMessage = "Phone number cannot exceed 15 characters")]
        public string Phone { get; set; }
        public bool Status { get; set; }

        [MaxLength(100, ErrorMessage = "FullName cannot exceed 100 characters")]
        public string FullName { get; set; }

        public ICollection<BookIssue>? BookIssues { get; set; }
        public ICollection<BorrowRequest>? BookRequests { get; set; }
        public ICollection<RefreshToken>? RefreshTokens { get; set; }
        public ICollection<ActivityLog>? ActivityLogs { get; set; }

        public StudentDetail? StudentDetail { get; set; }
        public WishList? WishList { get; set; }
    }
}
