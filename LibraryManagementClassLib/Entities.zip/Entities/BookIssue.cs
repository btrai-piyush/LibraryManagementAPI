﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementClassLib.Entities
{
    public enum IssueStatus
    {
        Returned,
        Active,
        Overdue
    }
    public class BookIssue: BaseEntity
    {
        public int BookId { get; set; }
        public int UserId { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime? ReturnDate { get; set; }
        public IssueStatus Status { get; set; }
        public bool isArchived { get; set; } = false;
        public Fine? Fine { get; set; }
        public Book Book { get; set; }
        public User User { get; set; }

    }
}
