﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryManagementClassLib.Entities
{
    public class Book: BaseEntity
    {
        public string Title { get; set; }
        public string ISBN { get; set; }
        public int TotalCopies { get; set; }
        public int AvailableCopies { get; set; }
        public int PublisherId { get; set; }
        public ICollection<Author> Authors { get; set; } = new List<Author>();
        public ICollection<Category> Categories { get; set; } = new List<Category>();
        public Publisher Publisher { get; set; }
        public ICollection<BookIssue>? BookIssues { get; set; } = new List<BookIssue>();
        public ICollection<BorrowRequest>? BookRequests { get; set; } = new List<BorrowRequest>();
        public ICollection<Subject> Subjects { get; set; }= new List<Subject>();
        public ICollection<WishList>? WishLists { get; set; }=new List<WishList>();
    }
}
